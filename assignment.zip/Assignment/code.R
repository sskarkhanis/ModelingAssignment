#Michel.Ballings@UGent.be
#Any questions you might have: please post them on the forum
############################################################################################################################
# Contents:
  
#1. Code to compute churn and definition of the time window
#2. Code skeleton ModelingBuilding
#3. Code skeleton ModelDeployment

############################################################################################################################
#1. Code to compute churn and definition of the time window


#Here is some preliminary code to compute the churn. I didn't have much time to spend on it so hopefully it doesn't contain an error. 
#Please mail me if you do find something strange.
#It implements a very simple definition of churn: if there is no startdate in the dependent period a customer is a churner.
#There are more complicated definition of churn but for the assignment this will do.
#The time window is also provided that you can use to develop your code.

str(subscriptions)
f <- "%d/%m/%Y"
start_ind <- as.Date("02/01/2006", f)
end_ind <- as.Date("01/02/2010", f)
start_dep <- as.Date("03/02/2010", f)
end_dep<- as.Date("03/02/2011", f)

#Check if the customers are active at end_ind
ActiveCustomerID <- subscriptions[subscriptions$StartDate <= end_ind & subscriptions$EndDate  > start_dep ,"CustomerID"]
ActiveCustomerID <- unique(ActiveCustomerID)
#length(ActiveCustomerID)#2122 Make sure your StartDate is of type date

#Select only the subscriptions of the active customers
subs <- subscriptions[subscriptions$Customer %in% ActiveCustomerID,]
# str(subs)#14637
subs$Churn <- ifelse((subs$StartDate >= start_dep & subs$StartDate <= end_dep),1,0 )

# table(subs$Churn)
#     0     1 
# 11062  3575 

churners <- aggregate(subs[,'Churn'],by=list(CustomerID=subs$CustomerID),sum)
colnames(churners)[2] <- "churn"
# str(churners)
# table(churners$churn)
# > table(churners$churn)
#    0    1    2    3    4    5    6    7    9   10   11   12   13 
#  119 1427  261   57  184   17    5    3    1    2    2   40    4 


# table(churners$churn)[1]/length(churners$churn)
#          0 
# 0.05607917 

# 5.6% churners

head(churners)
# > head(churners)
#   CustomerID churn
# 1       3407     1
# 2       3464     1
# 3       4107     2
# 4       4870     4
# 5       5413     1
# 6       6621     1

#small update to the definition thanks to Sarah Carron
churners$churn <- ifelse(churners$churn==0,1,0)
table(churners$churn)
#next step is to merge churners this with your predictors



############################################################################################################################
#2. Code skeleton ModelingBuilding

ModelBuilding <- function(start.ind, end.ind, start.dep, end.dep) {

#code to read in data from disk
  
#code to prepare the basetable of predictors and churn
  
#if you use algorithms that require tuning: code to make a training and validation set
  
#model(s) creation
  
#return model(s) or any other information that you need in the ModelDeployment (possibly in a list)

}


############################################################################################################################
#3. Code skeleton ModelDeployment

#The object parameter is what is returned from ModelingBuilding
ModelDeployment <- function(object, end.ind) {
  
#compute start.ind (the length of the independent period should be just as long as in ModelingBuilding

#code to read in data from disk
  
#code to prepare the basetable of predictors
  
#make predictions
  
#return predictions and the customerID

}